@echo off
setlocal
cd /d "%~dp0"
title Reparar dependencias

if not exist ".venv\Scripts\python.exe" (
  echo No existe la carpeta .venv. Ejecuta primero iniciar.bat.
  pause
  exit /b 1
)

echo Version de Python del entorno:
".venv\Scripts\python.exe" --version
echo.
echo Instalando torch y torchvision ^(puede tardar varios minutos^)...
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install --upgrade torch torchvision
echo.
echo Instalando el resto de librerias...
".venv\Scripts\python.exe" -m pip install --upgrade -r requirements.txt
echo.
echo ===== Resultado =====
".venv\Scripts\python.exe" -m pip show torchvision
echo.
".venv\Scripts\python.exe" -c "import flask, PIL, torch, torchvision, accelerate, transformers; print('Todo instalado correctamente')"
echo.
echo Si dice "Todo instalado correctamente", ya puedes ejecutar iniciar.bat
echo.
pause
