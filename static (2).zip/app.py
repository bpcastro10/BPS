"""Lector de cheques: backend Flask.

Recibe una imagen, la lee con el modelo GLM-OCR afinado y devuelve los datos
extraídos junto con el porcentaje de confianza de cada uno.

Uso:
    python app.py
    y abre http://127.0.0.1:5000
"""

import os
import sys
import tempfile
import threading
import time
import traceback
import webbrowser
from pathlib import Path

def _check_dependencies():
    """Avisa con el comando exacto si falta alguna librería (evita errores crípticos)."""
    import importlib.util

    required = {
        "torch": "torch",
        "torchvision": "torchvision",
        "PIL": "pillow",
        "flask": "flask",
        "accelerate": "accelerate",
        "transformers": "transformers",
    }
    missing = [pip for mod, pip in required.items() if importlib.util.find_spec(mod) is None]
    if missing:
        sys.exit(
            "\nFaltan estas librerias: " + ", ".join(missing) + "\n"
            "Instalalas con este comando (usa el mismo Python que esta ejecutando esto):\n\n"
            f'  "{sys.executable}" -m pip install ' + " ".join(missing) + "\n"
        )


_check_dependencies()

import torch
from flask import Flask, jsonify, request, send_from_directory
from PIL import Image, ImageOps, UnidentifiedImageError
from transformers import AutoModelForImageTextToText, AutoProcessor

from confidence import build_token_groups, compute_confidence, parse_json

# Soporte opcional para fotos HEIC/HEIF (iPhone): pip install pillow-heif
try:
    import pillow_heif

    pillow_heif.register_heif_opener()
except ImportError:
    pass

# --------------------------------------------------------------------------
# Configuración (todo se puede cambiar con variables de entorno)
# --------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = Path(os.environ.get("MODEL_PATH", BASE_DIR / "glm_ocr_merged"))
# Debe ser el mismo texto con el que se entrenó el modelo.
PROMPT = os.environ.get(
    "OCR_PROMPT", "Extrae los datos del cheque y detecta la firma en formato JSON"
)
MAX_NEW_TOKENS = int(os.environ.get("MAX_NEW_TOKENS", "1024"))
MAX_SIDE = int(os.environ.get("MAX_SIDE", "2400"))  # lado mayor máximo, en píxeles
MAX_UPLOAD_MB = 25
HOST = os.environ.get("HOST", "127.0.0.1")
PORT = int(os.environ.get("PORT", "5000"))

app = Flask(__name__, static_folder=str(BASE_DIR / "static"), static_url_path="/static")
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_MB * 1024 * 1024

processor = None
tokenizer = None
model = None
stop_ids = set()
generation_lock = threading.Lock()  # una lectura a la vez (la GPU es una sola)


def load_model():
    global processor, tokenizer, model, stop_ids

    if not (MODEL_PATH / "config.json").exists():
        sys.exit(
            f"No encuentro el modelo en: {MODEL_PATH}\n"
            "Pon la carpeta 'glm_ocr_merged' junto a app.py o define MODEL_PATH."
        )

    print(f"Cargando el modelo desde {MODEL_PATH} ...")
    processor = AutoProcessor.from_pretrained(str(MODEL_PATH), trust_remote_code=True)
    tokenizer = getattr(processor, "tokenizer", processor)
    dtype = torch.float16 if torch.cuda.is_available() else torch.float32
    model = AutoModelForImageTextToText.from_pretrained(
        str(MODEL_PATH), dtype=dtype, device_map="auto", trust_remote_code=True
    )
    model.eval()

    eos = model.generation_config.eos_token_id
    stop_ids = set(eos if isinstance(eos, (list, tuple)) else [eos])
    if model.generation_config.pad_token_id is not None:
        stop_ids.add(model.generation_config.pad_token_id)
    stop_ids.discard(None)
    print(f"Modelo listo en: {model.device}")


# --------------------------------------------------------------------------
# Inferencia
# --------------------------------------------------------------------------
@torch.inference_mode()
def read_image(image_path: str):
    """Ejecuta el modelo y devuelve (texto, ids generados, logprob de cada token)."""
    messages = [
        {
            "role": "user",
            "content": [
                {"type": "image", "path": image_path},
                {"type": "text", "text": PROMPT},
            ],
        }
    ]
    inputs = processor.apply_chat_template(
        messages,
        add_generation_prompt=True,
        tokenize=True,
        return_dict=True,
        return_tensors="pt",
    ).to(model.device)
    inputs.pop("token_type_ids", None)

    out = model.generate(
        **inputs,
        max_new_tokens=MAX_NEW_TOKENS,
        do_sample=False,
        output_scores=True,
        return_dict_in_generate=True,
    )

    prompt_len = inputs["input_ids"].shape[1]
    ids = out.sequences[0][prompt_len:].tolist()
    steps = min(len(ids), len(out.scores))
    ids = ids[:steps]

    # Probabilidad (en log) que el modelo dio a cada token que eligió.
    logprobs = []
    for step in range(steps):
        log_probs = torch.log_softmax(out.scores[step][0].float(), dim=-1)
        logprobs.append(log_probs[ids[step]].item())

    # Quitar los tokens de fin de texto del final.
    while ids and ids[-1] in stop_ids:
        ids.pop()
        logprobs.pop()

    def decode(token_ids):
        return tokenizer.decode(
            token_ids, skip_special_tokens=True, clean_up_tokenization_spaces=False
        )

    groups, text = build_token_groups(ids, logprobs, decode)
    overall, per_field = compute_confidence(text, groups, logprobs)
    return text.strip(), len(ids), overall, per_field


def prepare_image(file_storage) -> Image.Image:
    """Abre cualquier formato de imagen y lo deja en RGB y de tamaño razonable."""
    image = Image.open(file_storage.stream)
    image.load()  # primer fotograma si es GIF/TIFF animado
    image = ImageOps.exif_transpose(image)

    if image.mode in ("RGBA", "LA", "P"):
        image = image.convert("RGBA")
        background = Image.new("RGB", image.size, "white")
        background.paste(image, mask=image.getchannel("A"))
        image = background
    else:
        image = image.convert("RGB")

    longest = max(image.size)
    if longest > MAX_SIDE:
        scale = MAX_SIDE / longest
        image = image.resize(
            (round(image.width * scale), round(image.height * scale)),
            Image.Resampling.LANCZOS,
        )
    return image


def percent(value):
    return None if value is None else round(value * 100, 1)


# --------------------------------------------------------------------------
# Rutas
# --------------------------------------------------------------------------
@app.get("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "device": str(model.device) if model else None})


@app.post("/api/extract")
def extract():
    upload = request.files.get("image")
    if upload is None or upload.filename == "":
        return jsonify({"error": "No llegó ninguna imagen. Elige un archivo e inténtalo de nuevo."}), 400

    try:
        image = prepare_image(upload)
    except (UnidentifiedImageError, OSError):
        return jsonify({"error": "El archivo no es una imagen válida. Prueba con PNG, JPG, WEBP, BMP, TIFF o GIF."}), 400

    started = time.perf_counter()
    try:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "entrada.png"
            image.save(path)
            with generation_lock:
                text, token_count, overall, per_field = read_image(str(path))
    except torch.cuda.OutOfMemoryError:
        torch.cuda.empty_cache()
        return jsonify({"error": "La GPU se quedó sin memoria. Usa una imagen más pequeña o baja MAX_SIDE."}), 507
    except Exception as exc:  # noqa: BLE001
        traceback.print_exc()
        return jsonify({"error": f"El modelo falló al leer la imagen: {exc}"}), 500

    data = parse_json(text)
    fields = []
    if isinstance(data, dict):
        for key, value in data.items():
            fields.append(
                {"key": key, "value": value, "confidence": percent(per_field.get(key))}
            )

    return jsonify(
        {
            "text": text,
            "data": data,
            "fields": fields,
            "confidence": {"overall": percent(overall), "tokens": token_count},
            "seconds": round(time.perf_counter() - started, 1),
        }
    )


@app.errorhandler(413)
def too_large(_error):
    return jsonify({"error": f"La imagen supera los {MAX_UPLOAD_MB} MB. Reduce su tamaño e inténtalo de nuevo."}), 413


if __name__ == "__main__":
    load_model()
    url = f"http://{HOST}:{PORT}"
    print(f"Listo. Abre {url} en tu navegador (Ctrl+C para cerrar)")
    if os.environ.get("OPEN_BROWSER", "1") == "1":
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    app.run(host=HOST, port=PORT, threaded=True, debug=False)
