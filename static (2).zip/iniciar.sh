#!/usr/bin/env bash
cd "$(dirname "$0")" || exit 1

if [ ! -f glm_ocr_merged/config.json ]; then
  echo "No encuentro el modelo. Copia la carpeta glm_ocr_merged junto a este archivo."
  exit 1
fi

[ -d .venv ] || python3 -m venv .venv || { echo "Instala Python 3.10 o superior."; exit 1; }

if [ ! -f .venv/.instalado ]; then
  echo "Instalando dependencias (solo la primera vez)..."
  .venv/bin/pip install --upgrade pip && .venv/bin/pip install -r requirements.txt \
    && touch .venv/.instalado || { echo "Fallo la instalacion."; exit 1; }
fi

.venv/bin/python app.py
