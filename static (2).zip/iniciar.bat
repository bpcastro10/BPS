@echo off
setlocal
cd /d "%~dp0"
title Lector de cheques

if not exist "glm_ocr_merged\config.json" (
  echo.
  echo No encuentro el modelo. Copia la carpeta "glm_ocr_merged" junto a este archivo
  echo y vuelve a ejecutarlo. Debe contener model.safetensors, config.json, etc.
  echo.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Creando entorno de Python ^(solo la primera vez^)...
  py -3 -m venv .venv 2>nul || python -m venv .venv
  if errorlevel 1 (
    echo.
    echo No encuentro Python. Instala Python 3.10 o superior desde https://www.python.org
    echo y marca la casilla "Add Python to PATH" durante la instalacion.
    echo.
    pause
    exit /b 1
  )
)

rem Comprueba de verdad que las librerias esten instaladas; si falta alguna, las instala.
".venv\Scripts\python.exe" -c "import flask, PIL, torch, torchvision, accelerate, transformers" >nul 2>&1
if errorlevel 1 (
  echo Instalando o reparando dependencias ^(puede tardar varios minutos^)...
  ".venv\Scripts\python.exe" -m pip install --upgrade pip
  ".venv\Scripts\python.exe" -m pip install --upgrade -r requirements.txt
  if errorlevel 1 (
    echo.
    echo Fallo la instalacion. Revisa tu conexion a internet y vuelve a intentarlo.
    echo.
    pause
    exit /b 1
  )
  echo.
  echo Comprobando la instalacion...
  ".venv\Scripts\python.exe" -c "import flask, PIL, torch, torchvision, accelerate, transformers"
  if errorlevel 1 (
    echo.
    echo Las librerias siguen sin cargar. Copia el error de arriba y envialo para revisarlo.
    echo.
    pause
    exit /b 1
  )
)

echo.
echo Cargando el modelo. Se abrira el navegador cuando este listo...
echo Para cerrar el programa, cierra esta ventana.
echo.
".venv\Scripts\python.exe" app.py
echo.
pause
